import Erdos745.WrapUp.Proofs.Internal.Linked.W09_FixedFinal
import Erdos745.WrapUp.Contracts

namespace Erdos745.WrapUp.Proofs.W09_TREE_MASS

open Erdos745.WrapUp.Proofs.Internal.W09_TREE_MASS_NearMean
open Erdos745.WrapUp.Proofs.Internal.W09_TREE_MASS_NearVarianceTail
open Erdos745.WrapUp.Proofs.Internal.W09_TREE_MASS_FixedMean
open Erdos745.WrapUp.Proofs.Internal.W09_TREE_MASS_FixedVariance

theorem result : FiniteEnumerationStatement →
    RateStatement →
    TupleEstimatesStatement →
    AnalyticSumsStatement →
    TreeMassStatement := by
  intro hF hRate hT hA
  constructor
  · intro M hbare
    exact ⟨near_mean_boundedBy hRate hT hA hbare,
      near_variance_boundedBy hF hRate hT hA hbare⟩
  · intro M lam hadm hlam hdeg
    exact ⟨fixed_mean_boundedBy hRate hT hA hadm hlam hdeg,
      fixed_variance_boundedBy hF hRate hT hA hadm hlam hdeg⟩

end Erdos745.WrapUp.Proofs.W09_TREE_MASS
