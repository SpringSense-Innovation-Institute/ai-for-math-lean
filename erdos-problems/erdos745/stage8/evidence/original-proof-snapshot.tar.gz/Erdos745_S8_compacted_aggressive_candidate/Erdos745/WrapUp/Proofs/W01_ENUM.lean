import Erdos745.WrapUp.Proofs.Internal.Linked.W01_FiniteCore
import Erdos745.WrapUp.Proofs.Internal.Linked.W01_Pruefer
import Erdos745.WrapUp.Proofs.Internal.Linked.W01_Asymptotic
import Erdos745.WrapUp.Proofs.Internal.Linked.W01_Unicyclic
namespace Erdos745.WrapUp.Proofs.W01_ENUM

open Erdos745.WrapUp.Proofs.Internal

/-- Unconditional assembly of the finite graph laws and exact labelled
enumeration. -/
theorem result : FiniteEnumerationStatement := by
  have hforest := W01_ENUM_Pruefer.rootedForestFormula
  have ht := W01_ENUM_Trees.result hforest
  have hf := W01_ENUM_Finite.result ht.2
  have hunicyclic :=
    W01_ENUM_Unicyclic.unicyclic_formula_of_cycle_forest_decomposition
      hforest W01_ENUM_Decomposition.cycleForestDecomposition
  have ha := W01_ENUM_Asymptotic.result W01_ENUM_Midpoint.result hunicyclic
  exact ⟨hf.1, hf.2.1, hf.2.2.1, hf.2.2.2.1, hf.2.2.2.2.1,
    hf.2.2.2.2.2.1, hf.2.2.2.2.2.2, ht.1, ht.2, ha.1, ha.2.1,
    ha.2.2.1, ha.2.2.2⟩

end Erdos745.WrapUp.Proofs.W01_ENUM
