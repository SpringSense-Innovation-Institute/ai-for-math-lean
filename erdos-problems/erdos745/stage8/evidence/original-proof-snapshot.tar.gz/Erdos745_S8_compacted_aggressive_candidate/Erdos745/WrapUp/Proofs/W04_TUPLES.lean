import Erdos745.WrapUp.Proofs.Internal.Linked.W04_Public
namespace Erdos745.WrapUp.Proofs.W04_TUPLES

/-- Root-facing W04 producer. Historical facade lemmas were removed; the
substantive estimates remain in the canonical internal proof modules. -/
theorem result :
    FiniteEnumerationStatement → RateStatement → TupleEstimatesStatement := by
  intro hF _hRate
  exact ⟨
    Internal.W04_TUPLES_Public.globalEventually hF,
    Internal.W04_TUPLES_PublicNear.mixedEventually hF,
    Internal.W04_TUPLES_Compact.compactLocalEventually hF,
    Internal.W04_TUPLES_Public.separatedTailEventually hF
  ⟩

end Erdos745.WrapUp.Proofs.W04_TUPLES
