import Erdos745.WrapUp.Proofs.Internal.Linked.W10_Near
import Erdos745.WrapUp.Contracts

namespace Erdos745.WrapUp.Proofs.W10_GIANT

open Erdos745.WrapUp.Proofs.Internal.W10_GIANT_Near
open Erdos745.WrapUp.Proofs.Internal.W10_GIANT_Fixed

theorem result : FiniteEnumerationStatement →
    RateStatement →
    TupleEstimatesStatement →
    AnalyticSumsStatement →
    CyclicStructureStatement →
    TreeMassStatement →
    GiantStatement := by
  intro hF hRate hTuple hAnalytic hCyc hTree
  constructor
  · intro M hbare
    exact near_giant_branch hF hRate hTuple hCyc hTree M hbare
  · intro M lam hM hlam hdeg
    exact fixed_giant_branch hF hRate hTuple hCyc hTree M lam hM hlam hdeg

end Erdos745.WrapUp.Proofs.W10_GIANT
