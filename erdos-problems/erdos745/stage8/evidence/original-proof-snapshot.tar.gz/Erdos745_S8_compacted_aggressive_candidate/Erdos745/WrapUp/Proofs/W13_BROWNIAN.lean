import Erdos745.WrapUp.Proofs.Internal.Linked.W13_Nullity
namespace Erdos745.WrapUp.Proofs.W13_BROWNIAN

noncomputable section
open Filter MeasureTheory ProbabilityTheory
open scoped ENNReal

open Internal.W13_BROWNIAN_Law
open Internal.W13_BROWNIAN_Ranks
open Internal.W13_BROWNIAN_Regularity

local instance : MeasurableSpace BrownianPath := borel BrownianPath
local instance : BorelSpace BrownianPath := ⟨rfl⟩

/-- Root-facing Brownian foundation. The old fixedTime/postend/late
conditional-export ladder has been linked away. -/
theorem result : BrownianFoundationStatement := by
  unfold BrownianFoundationStatement
  refine ⟨brownianLaw_existsUnique, ?_⟩
  intro mu hmu lam
  have hgood : ∀ᵐ w ∂mu, GoodExcursionPath w lam :=
    Internal.W13_BROWNIAN_Geometry.ae_goodExcursionPath_of_fixedTime_null_postend_late
      mu hmu lam
      (Internal.W13_BROWNIAN_Nullity.fixedTime_reflected_zero_null mu hmu lam)
      (Internal.W13_BROWNIAN_Minima.ae_postend_descent mu hmu lam)
      (Internal.W13_BROWNIAN_LateExcursions.ae_late_exclusion mu hmu lam)
  refine ⟨hgood, ?_⟩
  intro i hi
  refine ⟨measurable_excursionRankExtended lam i, ?_⟩
  filter_upwards [hgood] with w hw
  exact excursionRankExtended_pos_lt_top_of_good w lam hw i hi

end

end Erdos745.WrapUp.Proofs.W13_BROWNIAN
