import Erdos745.WrapUp.Proofs.Internal.Linked.W15_Final
namespace Erdos745.WrapUp.Proofs.W15_CRITICAL

open Erdos745.WrapUp
open Erdos745.WrapUp.Proofs.Internal.W15_CRITICAL_PublicTransfer

/-- Exact conditional public critical target. -/
theorem result : BrownianFoundationStatement →
    ExplorationStatement →
    CriticalStatement := by
  intro hBrownian hExploration
  exact criticalLaw_of_public hBrownian hExploration

end Erdos745.WrapUp.Proofs.W15_CRITICAL
