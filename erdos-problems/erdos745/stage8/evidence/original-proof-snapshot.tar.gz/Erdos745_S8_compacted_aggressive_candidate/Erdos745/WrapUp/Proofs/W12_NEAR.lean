import Erdos745.WrapUp.Proofs.Internal.Linked.W12_Near
namespace Erdos745.WrapUp.Proofs.W12_NEAR

open Erdos745.WrapUp.Proofs.Internal.W12_NEAR_Laws

theorem result
    (hF : FiniteEnumerationStatement)
    (hR : RateStatement)
    (hP : PoissonStatement)
    (hS : SubcriticalExclusionStatement)
    (hC : CyclicStructureStatement)
    (hG : GiantStatement) : RequiredNearAtlasStatement := by
  exact ⟨barelySubcriticalLaw_of_inputs hF hR hP hS hC,
    barelySupercriticalLaw_of_inputs hF hR hP hC hG⟩

end Erdos745.WrapUp.Proofs.W12_NEAR
