import Erdos745.WrapUp.Proofs.Internal.Linked.W11_Fixed
namespace Erdos745.WrapUp.Proofs.W11_FIXED

open Erdos745.WrapUp.Proofs.Internal.W11_FIXED_Laws

theorem result : FiniteEnumerationStatement →
    RateStatement →
    PoissonStatement →
    SubcriticalExclusionStatement →
    CyclicStructureStatement →
    GiantStatement →
    FixedAtlasStatement :=
  fixedAtlasStatement_of_inputs

end Erdos745.WrapUp.Proofs.W11_FIXED
