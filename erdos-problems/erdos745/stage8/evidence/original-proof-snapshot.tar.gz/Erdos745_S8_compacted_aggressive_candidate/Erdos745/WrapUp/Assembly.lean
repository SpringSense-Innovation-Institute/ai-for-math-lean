import Erdos745.WrapUp.Proofs.W01_ENUM
import Erdos745.WrapUp.Proofs.W02_KERNEL
import Erdos745.WrapUp.Proofs.W03_RATE
import Erdos745.WrapUp.Proofs.W04_TUPLES
import Erdos745.WrapUp.Proofs.W05_SUMS
import Erdos745.WrapUp.Proofs.W06_POISSON
import Erdos745.WrapUp.Proofs.W07_SUBCRIT
import Erdos745.WrapUp.Proofs.W08_CYCLIC
import Erdos745.WrapUp.Proofs.W09_TREE_MASS
import Erdos745.WrapUp.Proofs.W10_GIANT
import Erdos745.WrapUp.Proofs.W11_FIXED
import Erdos745.WrapUp.Proofs.W12_NEAR
import Erdos745.WrapUp.Proofs.W13_BROWNIAN
import Erdos745.WrapUp.Proofs.W14_EXPLORATION
import Erdos745.WrapUp.Proofs.W15_CRITICAL

namespace Erdos745.WrapUp

/-- Conditional integration only. This does not manufacture the three inputs. -/
theorem assembleAtlas (hfixed : FixedAtlasStatement) (hnear : RequiredNearAtlasStatement)
    (hcritical : CriticalStatement) : AtlasStatement := by
  exact ⟨hfixed.1, hfixed.2, hnear.1, hnear.2, hcritical⟩

/-- One shared set of public producers closes both the fixed and near branches. -/
theorem fixedNearAtlas : FixedAtlasStatement ∧ RequiredNearAtlasStatement := by
  have hF : FiniteEnumerationStatement := Proofs.W01_ENUM.result
  have hR : RateStatement := Proofs.W03_RATE.result
  have hK : KernelBoundStatement := Proofs.W02_KERNEL.result hF
  have hT : TupleEstimatesStatement := Proofs.W04_TUPLES.result hF hR
  have hA : AnalyticSumsStatement := Proofs.W05_SUMS.result hF hR
  have hP : PoissonStatement := Proofs.W06_POISSON.result hF hR hT hA
  have hS : SubcriticalExclusionStatement := Proofs.W07_SUBCRIT.result hF hA
  have hC : CyclicStructureStatement := Proofs.W08_CYCLIC.result hF hK hR hT hA
  have hTree : TreeMassStatement := Proofs.W09_TREE_MASS.result hF hR hT hA
  have hG : GiantStatement := Proofs.W10_GIANT.result hF hR hT hA hC hTree
  exact ⟨Proofs.W11_FIXED.result hF hR hP hS hC hG,
    Proofs.W12_NEAR.result hF hR hP hS hC hG⟩

/-- The remaining Atlas input is exactly the critical branch. -/
theorem atlasOfCritical (hcritical : CriticalStatement) : AtlasStatement :=
  assembleAtlas fixedNearAtlas.1 fixedNearAtlas.2 hcritical

/-- The only remaining ROOT input is the exploration statement. -/
theorem atlasOfExploration (hExploration : ExplorationStatement) : AtlasStatement :=
  atlasOfCritical (Proofs.W15_CRITICAL.result Proofs.W13_BROWNIAN.result hExploration)

/-- The five sparse pointwise-sequence branches, with every task input discharged. -/
theorem atlas : AtlasStatement :=
  atlasOfExploration
    (Proofs.W14_EXPLORATION.result Proofs.W01_ENUM.result Proofs.W13_BROWNIAN.result)

end Erdos745.WrapUp
