import Erdos745.WrapUp.Proofs.Internal.Linked.W05_Analytic
namespace Erdos745.WrapUp.Proofs.W05_SUMS

open Erdos745.WrapUp

theorem result : FiniteEnumerationStatement →
    RateStatement →
    AnalyticSumsStatement := by
  intro hEnum hRate
  exact ⟨
    Internal.W05_SUMS_TreeSeries.result hEnum hRate,
    Internal.W05_SUMS_Tails.powerWeight,
    Internal.W05_SUMS_Tails.fixedTail,
    Internal.W05_SUMS_Tails.movingTail
  ⟩

end Erdos745.WrapUp.Proofs.W05_SUMS
