# Aggressive declaration-pruned candidate

This tree starts from the safe S8 linked release and additionally removes **238** declarations spanning **2829** source lines that have no consumer in a conservative source-level liveness closure rooted at `Erdos745.WrapUp.atlas`.

Measured against the original WrapUp: **71929 -> 68175 physical lines**, a **5.22%** reduction, while retaining 70 files.

This is **not promoted as compile-verified**. Source-level liveness cannot fully model Lean elaborator dependencies through global simp sets, typeclass search, custom attributes, or metaprogramming. Use the original project toolchain and run `COMPACTION/verify_in_project.sh`; only promote this candidate if Assembly elaborates cleanly.
