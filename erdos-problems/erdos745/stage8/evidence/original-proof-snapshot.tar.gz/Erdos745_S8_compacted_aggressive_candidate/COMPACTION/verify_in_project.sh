#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
cd "$ROOT"
if ! command -v lake >/dev/null 2>&1; then
  echo "lake not found" >&2; exit 2
fi
if [[ ! -f Erdos745/WrapUp/Assembly.lean ]]; then
  echo "Run from a project root containing Erdos745/WrapUp/Assembly.lean" >&2; exit 2
fi
echo "[1/2] elaborating Assembly"
lake env lean Erdos745/WrapUp/Assembly.lean
echo "[2/2] checking no legacy module imports remain"
if grep -R -nE '^import Erdos745\.WrapUp\.Proofs\.Internal\.W' Erdos745/WrapUp --include='*.lean'; then
  echo "legacy internal module import remains" >&2; exit 3
fi
echo "S8 compacted WrapUp verified."
