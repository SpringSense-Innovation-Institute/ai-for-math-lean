import Lake

open System Lake DSL

package lean_project where
  version := v!"0.1.0"
  keywords := #["math"]
  leanOptions :=
  #[⟨`pp.unicode.fun, true⟩, ⟨`relaxedAutoImplicit, false⟩, ⟨`weak.linter.mathlibStandardSet, false⟩,
    ⟨`maxSynthPendingDepth, 3⟩, ⟨`warningAsError, false⟩]

require "leanprover-community" / mathlib @ git "v4.29.0"

-- The canonical Stage 7--9 project library.
@[default_target] lean_lib Erdos448 where
  roots := #[`Erdos448]

-- Integration tests are a separate library so each worker can be checked
-- independently with `lake env lean`.
lean_lib Tests where
  roots := #[`Tests]

lean_lib Runs where
  roots := #[`Runs]
