import Erdos448.stage6.TaskContracts

namespace Erdos448.Stage7.DPMeanEXT001Adapter.Work

theorem result : Erdos448.Stage6.TaskContracts.DPMeanEXT001AdapterTarget :=
  Erdos448.Stage4.DependencyAdapters.adaptDPMeanT001

end Erdos448.Stage7.DPMeanEXT001Adapter.Work
