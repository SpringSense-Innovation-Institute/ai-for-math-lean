import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_CHEBYSHEV.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_FIRST_LEMMA.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_ZETA.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_TAIL.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_EXPINT.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MSC_ASSEMBLY.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MERT_CORRECTION.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MERT_PRODUCT_CORE.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MERT_ENDPOINTS.Result
import Erdos448.dependencies.«DP-MERTENS».stage7.tasks.TASK_MERT_FINAL.Result

namespace Erdos448.DPMertens.Stage8

open Erdos448.DPMertens.Lowering

noncomputable section

private def chebyshev : ChebyshevOutput :=
  Erdos448.DPMertens.Tasks.MSCChebyshev.result

private def firstLemma : FirstLemmaOutput :=
  Erdos448.DPMertens.Tasks.MSCFirstLemma.result chebyshev

private def correction : CorrectionOutput :=
  Erdos448.DPMertens.Tasks.MertCorrection.result

private def primeZeta : ZetaTaskOutput :=
  Erdos448.DPMertens.Tasks.MSCZeta.result correction

private def primeTail : TailTaskOutput :=
  Erdos448.DPMertens.Tasks.MSCTail.result firstLemma

private def expIntegral : ExpIntegralOutput :=
  Erdos448.DPMertens.Tasks.MSCExpInt.result

private def assembly : AssemblyTaskOutput :=
  Erdos448.DPMertens.Tasks.MSCAssembly.result primeZeta primeTail expIntegral

private def weakProduct : WeakProductTaskOutput :=
  Erdos448.DPMertens.Tasks.MertProductCore.result assembly correction

private def endpoints : EndpointOutput :=
  Erdos448.DPMertens.Tasks.MertEndpoints.result

private def finalPackage : FinalTaskOutput :=
  Erdos448.DPMertens.Tasks.MertFinal.result weakProduct endpoints

/-- The direct kernel-closed DP-MERTENS export. -/
theorem target : FT_MERTENS := by
  refine ⟨finalPackage.final.strict_asymptotic, ?_⟩
  exact ⟨finalPackage.final.X_M, finalPackage.final.c_M_minus,
    finalPackage.final.c_M_plus, finalPackage.final.X_M_ge_two,
    finalPackage.final.c_M_minus_pos, finalPackage.final.c_M_plus_pos,
    finalPackage.final.interval_comparison⟩

end

end Erdos448.DPMertens.Stage8
