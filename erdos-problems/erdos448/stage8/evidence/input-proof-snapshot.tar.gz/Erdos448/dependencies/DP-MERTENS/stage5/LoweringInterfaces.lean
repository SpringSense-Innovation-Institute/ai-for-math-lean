import Erdos448.dependencies.«DP-MERTENS».stage4.DP_Mertens_Design

/-!
Declaration-only interfaces for the executable S5 lowering record.

The content-addressed lowering library imports the frozen S4 declaration asset
before this file.  No declaration below asserts a theorem or contains a proof
body; task workers must construct the package values.
-/

open Filter Finset MeasureTheory Set
open scoped BigOperators Topology

namespace Erdos448.DPMertens.Lowering

noncomputable section

open Erdos448.DPMertens

/-! ## Closed task packages -/

structure ChebyshevOutput where
  increment : forall n : Nat, 0 < n ->
    theta (2 * n) - theta n <= (n : Real) * Real.log 4
  C_vartheta : Real
  C_vartheta_pos : 0 < C_vartheta
  weak_bound : forall t : Real, 2 <= t -> theta t <= C_vartheta * t

structure FirstLemmaOutput where
  C_V : Real
  C_V_nonneg : 0 <= C_V
  prime_power_bound : forall n : Nat, 2 <= n ->
    |primePowerSum n - Real.log n| <= C_V
  C_A : Real
  C_A_pos : 0 < C_A
  first_lemma : forall t : Real, 2 <= t ->
    |weightedPrimeSum t - Real.log t| <= C_A

structure CorrectionOutput where
  H : Real
  localCorrection : LocalCorrectionContract
  convergence : CorrectionConvergenceContract H
  tail : forall x : Real, 2 <= x ->
    0 <= H - correctionLE x /\ H - correctionLE x <= 2 / (x - 1)

def ZetaPoleNormalization : Prop :=
  Tendsto (fun rho : Real => zetaOnePlus rho - rho ^ (-1 : Int))
      rhoDownZero (nhds Real.eulerMascheroniConstant) /\
    Tendsto (fun rho : Real =>
      Real.log (zetaOnePlus rho) - Real.log (rho ^ (-1 : Int)))
      rhoDownZero (nhds 0)

structure PrimeZetaOutput (H : Real) where
  pole_normalization : ZetaPoleNormalization
  epsilon0 : Real -> Real
  formula : forall rho : Real, 0 < rho ->
    primeZetaOnePlus rho = Real.log (rho ^ (-1 : Int)) - H + epsilon0 rho
  epsilon0_tendsto : Tendsto epsilon0 rhoDownZero (nhds 0)

/-- Closed lowering package for P-MSC-03A/B.  The correction convergence,
analytic bridge, and public prime-zeta output all use this package's one `H`.
The task target consumes a local `corr : CorrectionOutput`, from which this
single witness is constructed. -/
structure ZetaTaskOutput where
  corr : CorrectionOutput
  analytic_bridge : PrimeZetaAnalyticBridge corr.H
  pole : ZetaPoleNormalization
  prime_zeta : PrimeZetaOutput corr.H

def primeTailIntegral (G rho : Real) : Real :=
  integral (volume.restrict (Ioi G))
    (fun t : Real => 1 / (Real.rpow t (1 + rho) * Real.log t))

structure PrimeTailOutputOf (C_A : Real) where
  mathcalE : Nat -> Real -> Real
  formula : forall G : Nat, 2 <= G -> forall rho : Real, 0 < rho ->
    (tsum fun p : Nat =>
      if p.Prime /\ G < p then Real.rpow p (-(1 + rho)) else 0) =
      primeTailIntegral G rho + mathcalE G rho
  uniform_bound : forall G : Nat, 2 <= G -> forall rho : Real, 0 < rho ->
    |mathcalE G rho| <= 2 * C_A / Real.log G

/-- The tail theorem carries the exact first-lemma package whose `C_A`
indexes its output. No independent tail constant can be selected. -/
structure TailTaskOutput where
  first : FirstLemmaOutput
  tail : PrimeTailOutputOf first.C_A

structure ExpIntegralOutput where
  epsilonG : Real -> Real -> Real
  formula : forall G : Real, 2 <= G -> forall rho : Real, 0 < rho ->
    primeTailIntegral G rho = Real.log (rho ^ (-1 : Int)) -
      Real.log (Real.log G) - Real.eulerMascheroniConstant + epsilonG G rho
  epsilonG_tendsto : forall G : Real, 2 <= G ->
    Tendsto (epsilonG G) rhoDownZero (nhds 0)

structure SumAssemblyOutput (H : Real) where
  data : SumConstantInterface
  same_H : data.H = H

/-- Closed carrier retaining the exact zeta/correction package used to build
the child output. -/
structure AssemblyTaskOutput where
  zeta : ZetaTaskOutput
  assembly : SumAssemblyOutput zeta.corr.H

structure WeakProductOutput (corr : CorrectionOutput)
    (child : SumAssemblyOutput corr.H) where
  finite_log : FiniteProductLogContract
  E : Real -> Real
  CE : Real
  XE : Real
  E_definition : forall x : Real, 2 <= x ->
    E x = (child.data.H - correctionLE x) - child.data.R x
  log_cancellation : forall x : Real, 2 <= x ->
    Real.log (qLE x) =
      -Real.log (Real.log x) - Real.eulerMascheroniConstant + E x
  E_rate : ReciprocalLogRate E CE XE
  E_tendsto : Tendsto E atTop (nhds 0)
  relativeError : Real -> Real
  CRelative : Real
  XRelative : Real
  relativeError_definition : forall x : Real, 2 <= x ->
    relativeError x = Real.exp (E x) - 1
  exact_exponential : forall x : Real, 2 <= x ->
    qLE x = mertensMain x * Real.exp (E x)
  exact_relative : forall x : Real, 2 <= x ->
    qLE x = mertensMain x * (1 + relativeError x)
  relative_rate : ReciprocalLogRate relativeError CRelative XRelative
  asymptotic : AtTopEquivalent qLE mertensMain

/-- Closed carrier preserving the dependent correction/child/weak-product
identity across task boundaries. -/
structure WeakProductTaskOutput where
  corr : CorrectionOutput
  child : SumAssemblyOutput corr.H
  weak : WeakProductOutput corr child

structure EndpointOutput where
  endpoint : EndpointContract
  interval : IntervalQuotientContract

structure FinalOutput (corr : CorrectionOutput)
    (child : SumAssemblyOutput corr.H)
    (weak : WeakProductOutput corr child) (ends : EndpointOutput) where
  strictRelativeError : Real -> Real
  CStrict : Real
  XStrict : Real
  strict_exact : forall x : Real, 2 <= x ->
    qLT x = mertensMain x * (1 + strictRelativeError x)
  strict_rate : ReciprocalLogRate strictRelativeError CStrict XStrict
  strict_asymptotic : StrictMertensAsymptotic
  X_M : Real
  c_M_minus : Real
  c_M_plus : Real
  X_M_ge_two : 2 <= X_M
  c_M_minus_pos : 0 < c_M_minus
  c_M_plus_pos : 0 < c_M_plus
  interval_comparison : forall A B : Real, X_M <= A -> A < B ->
    c_M_minus * (Real.log A / Real.log B) <= intervalProduct A B /\
    intervalProduct A B <= c_M_plus * (Real.log A / Real.log B)

/-- Closed carrier for the exact dependent final result. -/
structure FinalTaskOutput where
  corr : CorrectionOutput
  child : SumAssemblyOutput corr.H
  weak : WeakProductOutput corr child
  ends : EndpointOutput
  final : FinalOutput corr child weak ends

/-! ## Closed proposition interfaces for required proof objects -/

def P_MSC_01A : Prop := forall n : Nat, 0 < n ->
  theta (2 * n) - theta n <= (n : Real) * Real.log 4

def P_MSC_01B : Prop := exists C : Real, 0 < C /\
  forall t : Real, 2 <= t -> theta t <= C * t

def P_MSC_02A : Prop := exists C : Real, 0 <= C /\
  forall n : Nat, 2 <= n -> |primePowerSum n - Real.log n| <= C

def P_MSC_02B : Prop := exists C : Real, 0 < C /\
  forall t : Real, 2 <= t -> |weightedPrimeSum t - Real.log t| <= C

def P_MSC_03A : Prop := ZetaPoleNormalization

def P_MSC_03B : Prop := exists H : Real,
  CorrectionConvergenceContract H /\
  Nonempty (PrimeZetaAnalyticBridge H) /\ Nonempty (PrimeZetaOutput H)

def P_MSC_04 : Prop := Nonempty TailTaskOutput

def P_MSC_05 : Prop := Nonempty ExpIntegralOutput

def P_MSC_06A : Prop := exists d : SumConstantInterface,
  forall G : Nat, 2 <= G ->
    reciprocalPrimeSumNat G = Real.log (Real.log G) + d.B + d.Delta G /\
    |d.Delta G| <= d.C0 / Real.log G

def P_MSC_06B : Prop := exists d : SumConstantInterface,
  forall x : Real, 2 <= x ->
    reciprocalPrimeSum x = Real.log (Real.log x) + d.B + d.R x

def P_MSC_07 : Prop := exists H : Real,
  CorrectionConvergenceContract H /\
  forall x : Real, 2 <= x ->
    0 <= H - correctionLE x /\ H - correctionLE x <= 2 / (x - 1)

def EXT_MERT_01 : Prop := exists d : SumConstantInterface,
  (forall x : Real, 2 <= x ->
    reciprocalPrimeSum x = Real.log (Real.log x) + d.B + d.R x) /\
  ReciprocalLogRate d.R d.CR d.XR /\ Tendsto d.R atTop (nhds 0)

def EXT_MERT_02 : Prop := exists d : SumConstantInterface,
  d.B = Real.eulerMascheroniConstant - d.H

def P_MERT_01 : Prop := LocalCorrectionContract

def P_MERT_02 : Prop := exists H : Real, CorrectionConvergenceContract H

def P_MERT_03 : Prop := FiniteProductLogContract

def P_MERT_04 : Prop := Nonempty WeakProductTaskOutput

def P_MERT_05 : Prop := exists w : WeakProductTaskOutput,
  ReciprocalLogRate w.weak.relativeError w.weak.CRelative w.weak.XRelative /\
  AtTopEquivalent qLE mertensMain

def P_MERT_06A : Prop := EndpointContract

def P_MERT_06B : Prop := IntervalQuotientContract

def P_MERT_07 : Prop := exists f : FinalTaskOutput,
  ReciprocalLogRate f.final.strictRelativeError f.final.CStrict f.final.XStrict /\
  StrictMertensAsymptotic

def P_MERT_08 : Prop := IntervalComparisonContract

def FT_MERTENS : Prop := EXT002Contract

/-! ## Required definition interfaces -/

def D_MERT_01 (x : Real) : Real × Real × Real :=
  (qLE x, qLT x, endpointFactor x)

abbrev D_MERT_02 := CorrectionOutput

def D_MSC_01 (t rho : Real) (n : Nat) : Real × Real × Real × Real :=
  (theta t, weightedPrimeSum t, tailKernel rho t, primePowerSum n)

def S_MSC_01A : Prop := P_MSC_01A
def S_MSC_01B (C : Real) : Prop := 0 < C /\
  forall t : Real, 2 <= t -> theta t <= C * t
def S_MSC_02A (C : Real) : Prop := 0 <= C /\
  forall n : Nat, 2 <= n -> |primePowerSum n - Real.log n| <= C
def S_MSC_02B (C : Real) : Prop := 0 < C /\
  forall t : Real, 2 <= t -> |weightedPrimeSum t - Real.log t| <= C
def S_MSC_03A : Prop := ZetaPoleNormalization
def S_MSC_03B (epsilon0 : Real -> Real) : Prop :=
  exists H : Real, (forall rho : Real, 0 < rho ->
    primeZetaOnePlus rho = Real.log (rho ^ (-1 : Int)) - H + epsilon0 rho) /\
    Tendsto epsilon0 rhoDownZero (nhds 0)
def S_MSC_04 (C_A : Real) (mathcalE : Nat -> Real -> Real) : Prop :=
  forall G : Nat, 2 <= G -> forall rho : Real, 0 < rho ->
    |mathcalE G rho| <= 2 * C_A / Real.log G
def S_MSC_05 (epsilon : Real -> Real -> Real) : Prop :=
  forall G : Real, 2 <= G -> Tendsto (epsilon G) rhoDownZero (nhds 0)
def S_MSC_06A (B : Real) (Delta : Nat -> Real) (C0 : Real) : Prop :=
  forall G : Nat, 2 <= G ->
    reciprocalPrimeSumNat G = Real.log (Real.log G) + B + Delta G /\
    |Delta G| <= C0 / Real.log G
def S_MSC_06B (B : Real) (R : Real -> Real) (CR XR : Real) : Prop :=
  ReciprocalLogRate R CR XR /\ forall x : Real, 2 <= x ->
    reciprocalPrimeSum x = Real.log (Real.log x) + B + R x
def S_MSC_07 : Prop := P_MSC_07
def S_EXT_MERT_01 (B : Real) (R : Real -> Real) (CR XR : Real) : Prop :=
  ReciprocalLogRate R CR XR /\ Tendsto R atTop (nhds 0)
def S_EXT_MERT_02 (B : Real) : Prop := exists H : Real,
  B = Real.eulerMascheroniConstant - H
def S_MERT_01 : Prop := LocalCorrectionContract
def S_MERT_02 : Prop := P_MERT_02
def S_MERT_03 : Prop := FiniteProductLogContract
def S_MERT_04 (B : Real) (R E : Real -> Real) : Prop :=
  forall x : Real, 2 <= x -> E x = B - R x
def S_MERT_05 : Prop := P_MERT_05
def S_MERT_06A : Prop := EndpointContract
def S_MERT_06B : Prop := IntervalQuotientContract
def S_MERT_07 : Prop := P_MERT_07
def S_MERT_08 (X0 cMinus cPlus : Real) : Prop :=
  2 <= X0 /\ 0 < cMinus /\ 0 < cPlus /\
  forall A B : Real, X0 <= A -> A < B ->
    cMinus * (Real.log A / Real.log B) <= intervalProduct A B /\
    intervalProduct A B <= cPlus * (Real.log A / Real.log B)
def S_FT_MERTENS : Prop := StrictMertensAsymptotic

abbrev W_C_vartheta := Real
abbrev W_C_V := Real
abbrev W_C_A := Real
abbrev W_epsilon_0 := Real -> Real
abbrev W_mathcal_E := Nat -> Real -> Real
abbrev W_epsilon_G := Real -> Real -> Real
abbrev W_B := Real
abbrev W_Delta := Nat -> Real
abbrev W_C_0 := Real
abbrev W_R := Real -> Real
abbrev W_C_R := Real
abbrev W_X_R := Real
abbrev W_E := Real -> Real
abbrev W_X_0 := Real

/-! ## Frozen task telescopes -/

def TASK_MSC_CHEBYSHEV_Target := ChebyshevOutput

def TASK_MSC_FIRST_LEMMA_Target :=
  forall _hChebyshev : ChebyshevOutput, FirstLemmaOutput

def TASK_MSC_ZETA_Target :=
  forall _corr : CorrectionOutput, ZetaTaskOutput

def TASK_MSC_TAIL_Target :=
  forall _hFirstLemma : FirstLemmaOutput, TailTaskOutput

def TASK_MSC_EXPINT_Target := ExpIntegralOutput

def TASK_MSC_ASSEMBLY_Target :=
  forall (_hPrimeZeta : ZetaTaskOutput) (_hTail : TailTaskOutput)
    (_hExpInt : ExpIntegralOutput), AssemblyTaskOutput

def TASK_MERT_CORRECTION_Target := CorrectionOutput

def TASK_MERT_PRODUCT_CORE_Target :=
  forall (_hChild : AssemblyTaskOutput) (_hCorrection : CorrectionOutput),
    WeakProductTaskOutput

def TASK_MERT_ENDPOINTS_Target := EndpointOutput

def TASK_MERT_FINAL_Target :=
  forall (_hWeak : WeakProductTaskOutput) (_hEndpoints : EndpointOutput),
    FinalTaskOutput

end

end Erdos448.DPMertens.Lowering

/-! The lowering checker deliberately uses a conservative lexical declaration
screen.  These fully qualified transparent aliases make every S3 interface and
task target explicit without duplicating any definition or proof. -/

noncomputable def Erdos448.DPMertens.Lowering.I_D_MERT_01 (x : Real) :=
  Erdos448.DPMertens.Lowering.D_MERT_01 x
abbrev Erdos448.DPMertens.Lowering.I_D_MERT_02 :=
  Erdos448.DPMertens.Lowering.D_MERT_02
noncomputable def Erdos448.DPMertens.Lowering.I_D_MSC_01 (t rho : Real) (n : Nat) :=
  Erdos448.DPMertens.Lowering.D_MSC_01 t rho n

abbrev Erdos448.DPMertens.Lowering.I_S_MSC_01A := Erdos448.DPMertens.Lowering.S_MSC_01A
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_01B := Erdos448.DPMertens.Lowering.S_MSC_01B
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_02A := Erdos448.DPMertens.Lowering.S_MSC_02A
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_02B := Erdos448.DPMertens.Lowering.S_MSC_02B
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_03A := Erdos448.DPMertens.Lowering.S_MSC_03A
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_03B := Erdos448.DPMertens.Lowering.S_MSC_03B
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_04 := Erdos448.DPMertens.Lowering.S_MSC_04
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_05 := Erdos448.DPMertens.Lowering.S_MSC_05
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_06A := Erdos448.DPMertens.Lowering.S_MSC_06A
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_06B := Erdos448.DPMertens.Lowering.S_MSC_06B
abbrev Erdos448.DPMertens.Lowering.I_S_MSC_07 := Erdos448.DPMertens.Lowering.S_MSC_07
abbrev Erdos448.DPMertens.Lowering.I_S_EXT_MERT_01 := Erdos448.DPMertens.Lowering.S_EXT_MERT_01
abbrev Erdos448.DPMertens.Lowering.I_S_EXT_MERT_02 := Erdos448.DPMertens.Lowering.S_EXT_MERT_02
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_01 := Erdos448.DPMertens.Lowering.S_MERT_01
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_02 := Erdos448.DPMertens.Lowering.S_MERT_02
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_03 := Erdos448.DPMertens.Lowering.S_MERT_03
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_04 := Erdos448.DPMertens.Lowering.S_MERT_04
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_05 := Erdos448.DPMertens.Lowering.S_MERT_05
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_06A := Erdos448.DPMertens.Lowering.S_MERT_06A
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_06B := Erdos448.DPMertens.Lowering.S_MERT_06B
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_07 := Erdos448.DPMertens.Lowering.S_MERT_07
abbrev Erdos448.DPMertens.Lowering.I_S_MERT_08 := Erdos448.DPMertens.Lowering.S_MERT_08
abbrev Erdos448.DPMertens.Lowering.I_S_FT_MERTENS := Erdos448.DPMertens.Lowering.S_FT_MERTENS

abbrev Erdos448.DPMertens.Lowering.I_W_C_vartheta := Erdos448.DPMertens.Lowering.W_C_vartheta
abbrev Erdos448.DPMertens.Lowering.I_W_C_V := Erdos448.DPMertens.Lowering.W_C_V
abbrev Erdos448.DPMertens.Lowering.I_W_C_A := Erdos448.DPMertens.Lowering.W_C_A
abbrev Erdos448.DPMertens.Lowering.I_W_epsilon_0 := Erdos448.DPMertens.Lowering.W_epsilon_0
abbrev Erdos448.DPMertens.Lowering.I_W_mathcal_E := Erdos448.DPMertens.Lowering.W_mathcal_E
abbrev Erdos448.DPMertens.Lowering.I_W_epsilon_G := Erdos448.DPMertens.Lowering.W_epsilon_G
abbrev Erdos448.DPMertens.Lowering.I_W_B := Erdos448.DPMertens.Lowering.W_B
abbrev Erdos448.DPMertens.Lowering.I_W_Delta := Erdos448.DPMertens.Lowering.W_Delta
abbrev Erdos448.DPMertens.Lowering.I_W_C_0 := Erdos448.DPMertens.Lowering.W_C_0
abbrev Erdos448.DPMertens.Lowering.I_W_R := Erdos448.DPMertens.Lowering.W_R
abbrev Erdos448.DPMertens.Lowering.I_W_C_R := Erdos448.DPMertens.Lowering.W_C_R
abbrev Erdos448.DPMertens.Lowering.I_W_X_R := Erdos448.DPMertens.Lowering.W_X_R
abbrev Erdos448.DPMertens.Lowering.I_W_E := Erdos448.DPMertens.Lowering.W_E
abbrev Erdos448.DPMertens.Lowering.I_W_X_0 := Erdos448.DPMertens.Lowering.W_X_0

abbrev Erdos448.DPMertens.Lowering.I_P_MSC_01A := Erdos448.DPMertens.Lowering.P_MSC_01A
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_01B := Erdos448.DPMertens.Lowering.P_MSC_01B
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_02A := Erdos448.DPMertens.Lowering.P_MSC_02A
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_02B := Erdos448.DPMertens.Lowering.P_MSC_02B
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_03A := Erdos448.DPMertens.Lowering.P_MSC_03A
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_03B := Erdos448.DPMertens.Lowering.P_MSC_03B
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_04 := Erdos448.DPMertens.Lowering.P_MSC_04
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_05 := Erdos448.DPMertens.Lowering.P_MSC_05
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_06A := Erdos448.DPMertens.Lowering.P_MSC_06A
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_06B := Erdos448.DPMertens.Lowering.P_MSC_06B
abbrev Erdos448.DPMertens.Lowering.I_P_MSC_07 := Erdos448.DPMertens.Lowering.P_MSC_07
abbrev Erdos448.DPMertens.Lowering.I_EXT_MERT_01 := Erdos448.DPMertens.Lowering.EXT_MERT_01
abbrev Erdos448.DPMertens.Lowering.I_EXT_MERT_02 := Erdos448.DPMertens.Lowering.EXT_MERT_02
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_01 := Erdos448.DPMertens.Lowering.P_MERT_01
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_02 := Erdos448.DPMertens.Lowering.P_MERT_02
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_03 := Erdos448.DPMertens.Lowering.P_MERT_03
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_04 := Erdos448.DPMertens.Lowering.P_MERT_04
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_05 := Erdos448.DPMertens.Lowering.P_MERT_05
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_06A := Erdos448.DPMertens.Lowering.P_MERT_06A
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_06B := Erdos448.DPMertens.Lowering.P_MERT_06B
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_07 := Erdos448.DPMertens.Lowering.P_MERT_07
abbrev Erdos448.DPMertens.Lowering.I_P_MERT_08 := Erdos448.DPMertens.Lowering.P_MERT_08
abbrev Erdos448.DPMertens.Lowering.I_FT_MERTENS := Erdos448.DPMertens.Lowering.FT_MERTENS

abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_CHEBYSHEV_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_CHEBYSHEV_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_FIRST_LEMMA_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_FIRST_LEMMA_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_ZETA_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_ZETA_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_TAIL_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_TAIL_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_EXPINT_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_EXPINT_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MSC_ASSEMBLY_Target :=
  Erdos448.DPMertens.Lowering.TASK_MSC_ASSEMBLY_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MERT_CORRECTION_Target :=
  Erdos448.DPMertens.Lowering.TASK_MERT_CORRECTION_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MERT_PRODUCT_CORE_Target :=
  Erdos448.DPMertens.Lowering.TASK_MERT_PRODUCT_CORE_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MERT_ENDPOINTS_Target :=
  Erdos448.DPMertens.Lowering.TASK_MERT_ENDPOINTS_Target
abbrev Erdos448.DPMertens.Lowering.I_TASK_MERT_FINAL_Target :=
  Erdos448.DPMertens.Lowering.TASK_MERT_FINAL_Target
